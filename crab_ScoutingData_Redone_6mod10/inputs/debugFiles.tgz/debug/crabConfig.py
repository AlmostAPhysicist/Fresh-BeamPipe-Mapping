from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.transferOutputs = True
config.General.requestName = 'ScoutingData_Redone_6mod10'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.outputFiles = ['ScoutingTree_Output.root']
config.JobType.maxMemoryMB = 3000
config.JobType.maxJobRuntimeMin = 2750
config.JobType.psetName = 'UnifiedScoutingVertexingTreeMaker.py'
config.section_('Data')
config.Data.unitsPerJob = 2
config.Data.inputDataset = '/ScoutingPFRun3/Run2024H-v1/HLTSCOUT'
config.Data.publication = False
config.Data.outputDatasetTag = 'ScoutingData_Redone_6mod10'
config.Data.splitting = 'FileBased'
config.Data.inputDBS = 'global'
config.Data.allowNonValidInputDataset = True
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
