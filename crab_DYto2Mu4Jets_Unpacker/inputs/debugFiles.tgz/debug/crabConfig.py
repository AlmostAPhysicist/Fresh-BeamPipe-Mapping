from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'DYto2Mu4Jets_Unpacker'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'HLTScoutingUnpackProducer.py'
config.section_('Data')
config.Data.totalUnits = 1
config.Data.outputDatasetTag = 'DYto2Mu4Jets_Unpacker'
config.Data.splitting = 'FileBased'
config.Data.publication = True
config.Data.unitsPerJob = 1
config.Data.inputDataset = '/DYto2Mu-4Jets_Bin-MLL-50_TuneCP5_13p6TeV_madgraphMLM-pythia8/RunIII2024Summer24MiniAOD-140X_mcRun3_2024_realistic_v26-v2/MINIAODSIM'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
