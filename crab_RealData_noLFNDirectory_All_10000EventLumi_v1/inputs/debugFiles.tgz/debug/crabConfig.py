from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'RealData_noLFNDirectory_All_10000EventLumi_v1'
config.General.transferOutputs = True
config.General.transferLogs = True
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.maxJobRuntimeMin = 2000
config.JobType.psetName = 'UnifiedScoutingVertexingTreeMaker.py'
config.section_('Data')
config.Data.unitsPerJob = 10000
config.Data.splitting = 'EventAwareLumiBased'
config.Data.inputDBS = 'global'
config.Data.allowNonValidInputDataset = True
config.Data.outputDatasetTag = 'RealData_noLFNDirectory_All_10000EventLumi_v1'
config.Data.inputDataset = '/ScoutingPFRun3/Run2024H-v1/HLTSCOUT'
config.Data.publication = False
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
