from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.requestName = 'Data_ScoutingPFRun3_1mod10'
config.General.transferLogs = True
config.section_('JobType')
config.JobType.numCores = 4
config.JobType.maxJobRuntimeMin = 2750
config.JobType.pluginName = 'Analysis'
config.JobType.maxMemoryMB = 3000
config.JobType.psetName = 'UnifiedScoutingVertexingTreeMaker.py'
config.section_('Data')
config.Data.outputDatasetTag = 'Data_ScoutingPFRun3_1mod10'
config.Data.publication = False
config.Data.inputDBS = 'global'
config.Data.unitsPerJob = 2
config.Data.allowNonValidInputDataset = True
config.Data.inputDataset = '/ScoutingPFRun3/Run2024H-v1/HLTSCOUT'
config.Data.splitting = 'FileBased'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
