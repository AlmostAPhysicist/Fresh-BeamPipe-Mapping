from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.requestName = 'RealData_noLFNDirectory_All_6000EventLumi_v1'
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.maxJobRuntimeMin = 2000
config.JobType.psetName = 'UnifiedScoutingVertexingTreeMaker.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.outputDatasetTag = 'RealData_noLFNDirectory_All_6000EventLumi_v1'
config.Data.allowNonValidInputDataset = True
config.Data.unitsPerJob = 5000
config.Data.inputDBS = 'global'
config.Data.inputDataset = '/ScoutingPFRun3/Run2024H-v1/HLTSCOUT'
config.Data.splitting = 'EventAwareLumiBased'
config.Data.publication = False
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
