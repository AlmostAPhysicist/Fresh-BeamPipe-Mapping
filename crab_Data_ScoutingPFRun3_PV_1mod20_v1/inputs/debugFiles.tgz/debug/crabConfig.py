from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.transferOutputs = True
config.General.requestName = 'Data_ScoutingPFRun3_PV_1mod20_v1'
config.section_('JobType')
config.JobType.maxMemoryMB = 3000
config.JobType.psetName = 'UnifiedScoutingVertexingTreeMaker.py'
config.JobType.pluginName = 'Analysis'
config.JobType.outputFiles = ['DY2M_ScoutingTree_Output_PV.root']
config.JobType.maxJobRuntimeMin = 2750
config.section_('Data')
config.Data.publication = False
config.Data.inputDataset = '/ScoutingPFRun3/Run2024H-v1/HLTSCOUT'
config.Data.allowNonValidInputDataset = True
config.Data.outputDatasetTag = 'Data_ScoutingPFRun3_PV_1mod20_v1'
config.Data.unitsPerJob = 2
config.Data.splitting = 'FileBased'
config.Data.inputDBS = 'global'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
