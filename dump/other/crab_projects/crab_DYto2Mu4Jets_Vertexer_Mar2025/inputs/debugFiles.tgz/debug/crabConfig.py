from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crab_projects'
config.General.requestName = 'DYto2Mu4Jets_Vertexer_Mar2025'
config.General.transferLogs = True
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'Vertexer.py'
config.JobType.maxMemoryMB = 5000
config.section_('Data')
config.Data.unitsPerJob = 1
config.Data.userInputFiles = ['/store/mc/RunIII2024Summer24MiniAOD/DYto2Mu-4Jets_Bin-MLL-50_TuneCP5_13p6TeV_madgraphMLM-pythia8/MINIAODSIM/140X_mcRun3_2024_realistic_v26-v2/2560000/ad749229-3094-410f-94e3-2e408518e395.root']
config.Data.splitting = 'FileBased'
config.Data.outputDatasetTag = 'DYto2Mu4Jets_Vertexer_Mar2025'
config.Data.inputDBS = 'global'
config.Data.publication = False
config.section_('Site')
config.Site.storageSite = 'T2_BR_SPRACE'
config.section_('User')
config.section_('Debug')
