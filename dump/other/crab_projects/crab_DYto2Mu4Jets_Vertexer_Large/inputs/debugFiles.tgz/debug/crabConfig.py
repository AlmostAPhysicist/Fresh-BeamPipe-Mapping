from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.requestName = 'DYto2Mu4Jets_Vertexer_Large'
config.General.transferLogs = True
config.General.workArea = 'crab_projects'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.maxMemoryMB = 2500
config.JobType.psetName = 'Vertexer.py'
config.section_('Data')
config.Data.splitting = 'FileBased'
config.Data.outputDatasetTag = 'DYto2Mu4Jets_Vertexer_Large'
config.Data.inputDBS = 'phys03'
config.Data.unitsPerJob = 1
config.Data.publication = True
config.Data.inputDataset = '/DYto2Mu-4Jets_Bin-MLL-50_TuneCP5_13p6TeV_madgraphMLM-pythia8/amalhotr-DYto2Mu4Jets_Unpacker_Large-49feb6938084587a06052f9676570a55/USER'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
