#!/bin/bash

# Run TrackProducer
cmsRun TrackProducer.py

# Run VertexProducer
cmsRun VertexProducer.py

# Delete first intermediate file
rm scout.root

# Run TREE
cmsRun TREE.py

# Delete second intermediate file
rm DY2M_VertexerOutput.root

# Move final output to CRAB-specified file
mv DY2M_ScoutingTree_Output.root $1
