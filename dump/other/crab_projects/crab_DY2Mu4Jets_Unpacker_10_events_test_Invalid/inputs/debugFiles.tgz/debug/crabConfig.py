from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'DY2Mu4Jets_Unpacker_10_events_test_Invalid'
config.General.workArea = 'crab_projects'
config.General.transferOutputs = True
config.General.transferLogs = True
config.section_('JobType')
config.JobType.numCores = 1
config.JobType.scriptExe = 'run_chain.sh'
config.JobType.psetName = 'TrackProducer.py'
config.JobType.outputFiles = ['DY2M_ScoutingTree_Output.root']
config.JobType.inputFiles = ['TrackProducer.py', 'VertexProducer.py', 'TREE.py', 'run_chain.sh']
config.JobType.disableAutomaticOutputCollection = True
config.JobType.maxMemoryMB = 4000
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.allowNonValidInputDataset = True
config.Data.unitsPerJob = 1
config.Data.splitting = 'FileBased'
config.Data.publication = False
config.Data.totalUnits = 1
config.Data.outputDatasetTag = 'DY2Mu4Jets_Unpacker_100_test'
config.Data.outLFNDirBase = '/store/user/amalhotr/DY2Mu4Jets_ScoutingTree/'
config.Data.inputDBS = 'global'
config.Data.inputDataset = '/DYto2Mu-4Jets_Bin-MLL-50_TuneCP5_13p6TeV_madgraphMLM-pythia8/RunIII2024Summer24MiniAOD-140X_mcRun3_2024_realistic_v26-v2/MINIAODSIM'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
