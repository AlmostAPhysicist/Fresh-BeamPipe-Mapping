import FWCore.ParameterSet.Config as cms

hltScoutingUnpackProducer = cms.EDProducer('HLTScoutingUnpackProducer',
  scoutingTrack = cms.InputTag('hltScoutingTrack'),
  scoutingPrimaryVertex = cms.InputTag('hltScoutingPrimaryVertex'),
  producePFCHSCandidate = cms.bool(False),
  mightGet = cms.optional.untracked.vstring
)
