from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'DYto2Mu4Jets_ScoutingTree_100_Local'
config.General.workArea = 'crab_projects'
config.General.transferLogs = True
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.maxMemoryMB = 2500
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'tree.py'
config.section_('Data')
config.Data.inputDataset = '/DYto2Mu-4Jets_Bin-MLL-50_TuneCP5_13p6TeV_madgraphMLM-pythia8/amalhotr-DYto2Mu4Jets_Vertexer_100_EventAwareLumiBased-8eb043b42a967140b9dd5cab43cfc767/USER'
config.Data.unitsPerJob = 5
config.Data.splitting = 'FileBased'
config.Data.outputDatasetTag = 'DYto2Mu4Jets_ScoutingTree_100_Local'
config.Data.inputDBS = 'phys03'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
