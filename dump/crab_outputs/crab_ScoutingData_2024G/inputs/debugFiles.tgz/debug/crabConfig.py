from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.transferLogs = True
config.General.requestName = 'ScoutingData_2024G'
config.section_('JobType')
config.JobType.maxMemoryMB = 3000
config.JobType.psetName = 'UnifiedScoutingVertexingTreeMaker.py'
config.JobType.outputFiles = ['ScoutingTree_Output.root']
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.splitting = 'Automatic'
config.Data.outputDatasetTag = 'ScoutingData_2024G'
config.Data.publication = False
config.Data.allowNonValidInputDataset = True
config.Data.inputDataset = '/ScoutingPFRun3/Run2024G-v1/HLTSCOUT'
config.Data.inputDBS = 'global'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
