from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.transferOutputs = True
config.General.requestName = 'MC_DYto2Mu_FullPV_0mod3_v1'
config.section_('JobType')
config.JobType.maxMemoryMB = 3000
config.JobType.outputFiles = ['DY2M_ScoutingTree_Output_PV.root']
config.JobType.psetName = 'UnifiedScoutingVertexingTreeMaker.py'
config.JobType.pluginName = 'Analysis'
config.JobType.maxJobRuntimeMin = 2750
config.section_('Data')
config.Data.inputDataset = '/DYto2Mu-4Jets_Bin-MLL-50_TuneCP5_13p6TeV_madgraphMLM-pythia8/RunIII2024Summer24MiniAOD-140X_mcRun3_2024_realistic_v26-v3/MINIAODSIM'
config.Data.inputDBS = 'global'
config.Data.allowNonValidInputDataset = True
config.Data.publication = False
config.Data.unitsPerJob = 1
config.Data.outputDatasetTag = 'MC_DYto2Mu_FullPV_0mod3_v1'
config.Data.splitting = 'FileBased'
config.Data.totalUnits = 1000
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
