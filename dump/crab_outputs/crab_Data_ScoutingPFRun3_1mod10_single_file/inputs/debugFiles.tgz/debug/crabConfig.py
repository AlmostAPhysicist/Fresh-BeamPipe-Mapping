from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.transferLogs = True
config.General.requestName = 'Data_ScoutingPFRun3_1mod10_single_file'
config.section_('JobType')
config.JobType.maxJobRuntimeMin = 2750
config.JobType.psetName = 'UnifiedScoutingVertexingTreeMaker.py'
config.JobType.pluginName = 'Analysis'
config.JobType.maxMemoryMB = 3000
config.JobType.outputFiles = ['DY2M_ScoutingTree_Output.root']
config.section_('Data')
config.Data.inputDataset = '/ScoutingPFRun3/Run2024H-v1/HLTSCOUT'
config.Data.publication = False
config.Data.outputDatasetTag = 'Data_ScoutingPFRun3_1mod10_single_file'
config.Data.unitsPerJob = 1
config.Data.inputDBS = 'global'
config.Data.allowNonValidInputDataset = True
config.Data.totalUnits = 2
config.Data.splitting = 'FileBased'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
