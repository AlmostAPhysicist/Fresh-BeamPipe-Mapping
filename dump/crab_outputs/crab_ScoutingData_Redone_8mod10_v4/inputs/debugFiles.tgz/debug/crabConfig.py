from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.transferLogs = True
config.General.requestName = 'ScoutingData_Redone_8mod10_v4'
config.section_('JobType')
config.JobType.maxMemoryMB = 3000
config.JobType.outputFiles = ['ScoutingTree_Output.root']
config.JobType.maxJobRuntimeMin = 2750
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'UnifiedScoutingVertexingTreeMaker.py'
config.section_('Data')
config.Data.allowNonValidInputDataset = True
config.Data.unitsPerJob = 2
config.Data.inputDataset = '/ScoutingPFRun3/Run2024H-v1/HLTSCOUT'
config.Data.splitting = 'FileBased'
config.Data.inputDBS = 'global'
config.Data.publication = False
config.Data.outputDatasetTag = 'ScoutingData_Redone_8mod10_v4'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
