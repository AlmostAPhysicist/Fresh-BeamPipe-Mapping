from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'RealData_noLFNDirectory_All_EventAwareLumiBased_10k_50M'
config.General.transferOutputs = True
config.General.transferLogs = True
config.section_('JobType')
config.JobType.psetName = 'UnifiedScoutingVertexingTreeMaker.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.unitsPerJob = 10000
config.Data.inputDataset = '/ScoutingPFRun3/Run2024H-v1/HLTSCOUT'
config.Data.publication = False
config.Data.outputDatasetTag = 'RealData_noLFNDirectory_All_EventAwareLumiBased_10k_50M'
config.Data.inputDBS = 'global'
config.Data.totalUnits = 50000000
config.Data.allowNonValidInputDataset = True
config.Data.splitting = 'EventAwareLumiBased'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
