import FWCore.ParameterSet.Config as cms

hltScoutingUnpackProducer = cms.EDProducer('HLTScoutingUnpackProducer',
  scoutingTrack = cms.InputTag('hltScoutingTrack'),
  scoutingPrimaryVertex = cms.InputTag('hltScoutingPrimaryVertex'),
  pfCand = cms.InputTag(''),
  lostTrack = cms.InputTag(''),
  isScouting = cms.bool(True),
  producePFCHSCandidate = cms.bool(False),
  mightGet = cms.optional.untracked.vstring
)
