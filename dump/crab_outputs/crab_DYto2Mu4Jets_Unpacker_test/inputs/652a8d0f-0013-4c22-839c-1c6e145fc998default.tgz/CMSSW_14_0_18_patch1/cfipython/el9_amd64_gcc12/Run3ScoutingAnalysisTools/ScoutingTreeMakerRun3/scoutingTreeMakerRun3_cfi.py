import FWCore.ParameterSet.Config as cms

scoutingTreeMakerRun3 = cms.EDAnalyzer('ScoutingTreeMakerRun3',
  required_ntk = cms.required.int32,
  pfjets = cms.required.InputTag,
  displacedVertices = cms.required.InputTag,
  unpackVertices = cms.required.InputTag,
  beamspot_src = cms.required.InputTag,
  mightGet = cms.optional.untracked.vstring
)
