__path__.append('/cvmfs/cms.cern.ch/el9_amd64_gcc12/cms/cmssw-patch/CMSSW_14_0_18_patch1/python/Run3ScoutingAnalysisTools')
