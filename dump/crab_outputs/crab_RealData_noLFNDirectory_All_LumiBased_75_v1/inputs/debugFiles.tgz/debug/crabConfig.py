from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'RealData_noLFNDirectory_All_LumiBased_75_v1'
config.General.transferOutputs = True
config.General.transferLogs = True
config.section_('JobType')
config.JobType.psetName = 'UnifiedScoutingVertexingTreeMaker.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.publication = False
config.Data.outputDatasetTag = 'RealData_noLFNDirectory_All_LumiBased_75_v1'
config.Data.unitsPerJob = 75
config.Data.inputDBS = 'global'
config.Data.inputDataset = '/ScoutingPFRun3/Run2024H-v1/HLTSCOUT'
config.Data.splitting = 'LumiBased'
config.Data.allowNonValidInputDataset = True
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
