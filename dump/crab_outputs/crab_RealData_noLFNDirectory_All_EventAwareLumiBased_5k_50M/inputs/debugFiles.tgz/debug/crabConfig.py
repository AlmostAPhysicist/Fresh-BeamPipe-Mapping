from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.transferLogs = True
config.General.requestName = 'RealData_noLFNDirectory_All_EventAwareLumiBased_5k_50M'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'UnifiedScoutingVertexingTreeMaker.py'
config.section_('Data')
config.Data.totalUnits = 50000000
config.Data.inputDBS = 'global'
config.Data.publication = False
config.Data.unitsPerJob = 5000
config.Data.outputDatasetTag = 'RealData_noLFNDirectory_All_EventAwareLumiBased_5k_50M'
config.Data.allowNonValidInputDataset = True
config.Data.inputDataset = '/ScoutingPFRun3/Run2024H-v1/HLTSCOUT'
config.Data.splitting = 'EventAwareLumiBased'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
