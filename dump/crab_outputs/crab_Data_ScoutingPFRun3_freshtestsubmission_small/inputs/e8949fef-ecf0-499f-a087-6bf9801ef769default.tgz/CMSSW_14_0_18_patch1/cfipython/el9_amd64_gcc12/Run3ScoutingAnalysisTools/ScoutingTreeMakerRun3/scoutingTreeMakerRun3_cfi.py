import FWCore.ParameterSet.Config as cms

scoutingTreeMakerRun3 = cms.EDAnalyzer('ScoutingTreeMakerRun3',
  required_ntk_min = cms.int32(-1),
  required_ntk_max = cms.int32(-1),
  required_invmass = cms.double(-1),
  required_chi2 = cms.double(-1),
  required_dBV_min = cms.double(-1),
  required_dBV_max = cms.double(-1),
  required_dxy_min = cms.double(-1),
  required_dxy_max = cms.double(-1),
  required_dBV_error = cms.double(-1),
  required_dxy_error = cms.double(-1),
  displacedVertices = cms.InputTag('displacedVertices'),
  beamspot_src = cms.InputTag('offlineBeamSpot'),
  tracks = cms.InputTag('hltScoutingUnpackProducer', 'Track'),
  mightGet = cms.optional.untracked.vstring
)
