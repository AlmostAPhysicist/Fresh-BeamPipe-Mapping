from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.requestName = 'Data_ScoutingPFRun3_freshtestsubmission_small'
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.maxJobRuntimeMin = 2750
config.JobType.psetName = 'UnifiedScoutingVertexingTreeMaker.py'
config.JobType.maxMemoryMB = 3000
config.JobType.pluginName = 'Analysis'
config.JobType.numCores = 4
config.section_('Data')
config.Data.outputDatasetTag = 'Data_ScoutingPFRun3_freshtestsubmission_small'
config.Data.inputDataset = '/ScoutingPFRun3/Run2024H-v1/HLTSCOUT'
config.Data.splitting = 'FileBased'
config.Data.allowNonValidInputDataset = True
config.Data.publication = False
config.Data.unitsPerJob = 2
config.Data.totalUnits = 10
config.Data.inputDBS = 'global'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
