from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.transferLogs = True
config.General.requestName = 'ScoutingData_Redone_9mod10_v2'
config.section_('JobType')
config.JobType.maxMemoryMB = 3500
config.JobType.maxJobRuntimeMin = 2750
config.JobType.psetName = 'UnifiedScoutingVertexingTreeMaker.py'
config.JobType.pluginName = 'Analysis'
config.JobType.outputFiles = ['ScoutingTree_Output.root']
config.section_('Data')
config.Data.unitsPerJob = 2
config.Data.allowNonValidInputDataset = True
config.Data.inputDBS = 'global'
config.Data.publication = False
config.Data.outputDatasetTag = 'ScoutingData_Redone_9mod10_v2'
config.Data.splitting = 'FileBased'
config.Data.inputDataset = '/ScoutingPFRun3/Run2024H-v1/HLTSCOUT'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
