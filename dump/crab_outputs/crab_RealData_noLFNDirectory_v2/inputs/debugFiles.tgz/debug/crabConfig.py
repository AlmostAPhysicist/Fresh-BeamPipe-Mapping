from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.transferLogs = True
config.General.requestName = 'RealData_noLFNDirectory_v2'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.maxJobRuntimeMin = 2000
config.JobType.psetName = 'UnifiedScoutingVertexingTreeMaker.py'
config.section_('Data')
config.Data.inputDataset = '/ScoutingPFRun3/Run2024H-v1/HLTSCOUT'
config.Data.unitsPerJob = 100
config.Data.splitting = 'EventAwareLumiBased'
config.Data.allowNonValidInputDataset = True
config.Data.inputDBS = 'global'
config.Data.totalUnits = 1000
config.Data.publication = False
config.Data.outputDatasetTag = 'RealData_noLFNDirectory_v2'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
