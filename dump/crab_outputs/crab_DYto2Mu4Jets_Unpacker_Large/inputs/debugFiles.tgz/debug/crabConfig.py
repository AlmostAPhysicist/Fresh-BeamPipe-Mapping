from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.transferLogs = True
config.General.requestName = 'DYto2Mu4Jets_Unpacker_Large'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'HLTScoutingUnpackProducer.py'
config.section_('Data')
config.Data.publication = True
config.Data.inputDataset = '/DYto2Mu-4Jets_Bin-MLL-50_TuneCP5_13p6TeV_madgraphMLM-pythia8/RunIII2024Summer24MiniAOD-140X_mcRun3_2024_realistic_v26-v2/MINIAODSIM'
config.Data.unitsPerJob = 5
config.Data.outputDatasetTag = 'DYto2Mu4Jets_Unpacker_Large'
config.Data.totalUnits = 75
config.Data.splitting = 'FileBased'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
