from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.requestName = 'ScoutingMC_FullPV_1mod2_v1'
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'UnifiedScoutingVertexingTreeMaker.py'
config.JobType.maxMemoryMB = 3000
config.JobType.outputFiles = ['ScoutingTree_Output_PV.root']
config.JobType.maxJobRuntimeMin = 2750
config.section_('Data')
config.Data.unitsPerJob = 2
config.Data.inputDataset = '/DYto2Mu-4Jets_Bin-MLL-50_TuneCP5_13p6TeV_madgraphMLM-pythia8/RunIII2024Summer24MiniAOD-140X_mcRun3_2024_realistic_v26-v3/MINIAODSIM'
config.Data.inputDBS = 'global'
config.Data.outputDatasetTag = 'ScoutingMC_FullPV_1mod2_v1'
config.Data.splitting = 'FileBased'
config.Data.allowNonValidInputDataset = True
config.Data.publication = False
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
