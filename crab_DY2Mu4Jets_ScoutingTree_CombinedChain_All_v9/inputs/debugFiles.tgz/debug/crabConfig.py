from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.transferLogs = True
config.General.requestName = 'DY2Mu4Jets_ScoutingTree_CombinedChain_All_v9'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'UnifiedScoutingVertexingTreeMaker.py'
config.JobType.maxJobRuntimeMin = 2000
config.section_('Data')
config.Data.inputDBS = 'global'
config.Data.unitsPerJob = 50000
config.Data.allowNonValidInputDataset = True
config.Data.inputDataset = '/DYto2Mu-4Jets_Bin-MLL-50_TuneCP5_13p6TeV_madgraphMLM-pythia8/RunIII2024Summer24MiniAOD-140X_mcRun3_2024_realistic_v26-v2/MINIAODSIM'
config.Data.outputDatasetTag = 'DY2Mu4Jets_ScoutingTree_CombinedChain_All_v9'
config.Data.publication = False
config.Data.splitting = 'EventAwareLumiBased'
config.Data.outLFNDirBase = '/store/user/amalhotr/DY2Mu4Jets_ScoutingTree/'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
