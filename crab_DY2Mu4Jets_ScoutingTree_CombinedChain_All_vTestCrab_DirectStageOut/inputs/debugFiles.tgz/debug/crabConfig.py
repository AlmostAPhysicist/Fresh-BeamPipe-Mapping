from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.transferOutputs = True
config.General.requestName = 'DY2Mu4Jets_ScoutingTree_CombinedChain_All_vTestCrab_DirectStageOut'
config.section_('JobType')
config.JobType.maxJobRuntimeMin = 2000
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'UnifiedScoutingVertexingTreeMaker.py'
config.section_('Data')
config.Data.unitsPerJob = 100
config.Data.outputDatasetTag = 'DY2Mu4Jets_ScoutingTree_CombinedChain_All_vTestCrab_DirectStageOut'
config.Data.totalUnits = 1000
config.Data.splitting = 'EventAwareLumiBased'
config.Data.publication = False
config.Data.inputDBS = 'global'
config.Data.inputDataset = '/DYto2Mu-4Jets_Bin-MLL-50_TuneCP5_13p6TeV_madgraphMLM-pythia8/RunIII2024Summer24MiniAOD-140X_mcRun3_2024_realistic_v26-v2/MINIAODSIM'
config.Data.allowNonValidInputDataset = True
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
