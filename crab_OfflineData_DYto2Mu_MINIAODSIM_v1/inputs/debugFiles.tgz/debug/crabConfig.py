from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'OfflineData_DYto2Mu_MINIAODSIM_v1'
config.General.transferLogs = True
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.maxMemoryMB = 2500
config.JobType.outputFiles = ['OfflineData_VertexingPlots_DYto2Mu_MINIAODSIM.root']
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'UnifiedOfflineVertexingPlotMaker.py'
config.section_('Data')
config.Data.totalUnits = 10000
config.Data.unitsPerJob = 5
config.Data.publication = False
config.Data.inputDataset = '/DYto2Mu-4Jets_Bin-MLL-50_TuneCP5_13p6TeV_madgraphMLM-pythia8/RunIII2024Summer24MiniAOD-140X_mcRun3_2024_realistic_v26-v3/MINIAODSIM'
config.Data.allowNonValidInputDataset = True
config.Data.inputDBS = 'global'
config.Data.splitting = 'FileBased'
config.Data.outputDatasetTag = 'OfflineData_DYto2Mu_MINIAODSIM_v1'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
