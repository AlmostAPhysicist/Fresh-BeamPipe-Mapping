from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'ScoutingData_Redone_3mod10_v4'
config.General.transferLogs = True
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.maxMemoryMB = 3000
config.JobType.pluginName = 'Analysis'
config.JobType.maxJobRuntimeMin = 2750
config.JobType.outputFiles = ['ScoutingTree_Output.root']
config.JobType.psetName = 'UnifiedScoutingVertexingTreeMaker.py'
config.section_('Data')
config.Data.outputDatasetTag = 'ScoutingData_Redone_3mod10_v4'
config.Data.inputDataset = '/ScoutingPFRun3/Run2024H-v1/HLTSCOUT'
config.Data.splitting = 'FileBased'
config.Data.publication = False
config.Data.unitsPerJob = 2
config.Data.allowNonValidInputDataset = True
config.Data.inputDBS = 'global'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
