import FWCore.ParameterSet.Config as cms

tree2PlotsRun3 = cms.EDAnalyzer('Tree2PlotsRun3',
  inputFile = cms.string('ScoutingTree_Output.root'),
  inputTree = cms.string('scoutingTree/vertexTree'),
  cut_ntk = cms.VPSet(
  ),
  cut_opening_angle_min = cms.vdouble(-1),
  required_invmass = cms.double(-1),
  required_chi2 = cms.double(-1),
  required_dBV_min = cms.double(-1),
  required_dBV_max = cms.double(-1),
  PVBoundary1 = cms.int32(-1),
  PVBoundary2 = cms.int32(-1),
  mightGet = cms.optional.untracked.vstring
)
