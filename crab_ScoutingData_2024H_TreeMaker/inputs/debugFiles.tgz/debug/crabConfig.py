from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.requestName = 'ScoutingData_2024H_TreeMaker'
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.maxMemoryMB = 3000
config.JobType.psetName = 'UnifiedScoutingVertexingTreeMaker.py'
config.JobType.outputFiles = ['ScoutingTree_Output.root']
config.section_('Data')
config.Data.splitting = 'FileBased'
config.Data.allowNonValidInputDataset = True
config.Data.inputDBS = 'global'
config.Data.publication = False
config.Data.outputDatasetTag = 'ScoutingData_2024H_TreeMaker'
config.Data.inputDataset = '/ScoutingPFRun3/Run2024H-v1/HLTSCOUT'
config.Data.unitsPerJob = 30
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
