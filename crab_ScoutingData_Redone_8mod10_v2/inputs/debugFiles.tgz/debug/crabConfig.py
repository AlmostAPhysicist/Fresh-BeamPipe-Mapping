from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.requestName = 'ScoutingData_Redone_8mod10_v2'
config.General.transferLogs = True
config.section_('JobType')
config.JobType.psetName = 'UnifiedScoutingVertexingTreeMaker.py'
config.JobType.maxMemoryMB = 3500
config.JobType.outputFiles = ['ScoutingTree_Output.root']
config.JobType.pluginName = 'Analysis'
config.JobType.maxJobRuntimeMin = 2750
config.section_('Data')
config.Data.splitting = 'FileBased'
config.Data.allowNonValidInputDataset = True
config.Data.outputDatasetTag = 'ScoutingData_Redone_8mod10_v2'
config.Data.unitsPerJob = 2
config.Data.inputDataset = '/ScoutingPFRun3/Run2024H-v1/HLTSCOUT'
config.Data.publication = False
config.Data.inputDBS = 'global'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
