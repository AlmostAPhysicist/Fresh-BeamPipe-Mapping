from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.requestName = 'RealData_noLFNDirectory_All_FileBased_10000_v1'
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.psetName = 'UnifiedScoutingVertexingTreeMaker.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.unitsPerJob = 1
config.Data.publication = False
config.Data.splitting = 'FileBased'
config.Data.inputDataset = '/ScoutingPFRun3/Run2024H-v1/HLTSCOUT'
config.Data.allowNonValidInputDataset = True
config.Data.totalUnits = 10000
config.Data.outputDatasetTag = 'RealData_noLFNDirectory_All_FileBased_10000_v1'
config.Data.inputDBS = 'global'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
