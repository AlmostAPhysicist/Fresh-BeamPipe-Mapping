from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.transferOutputs = True
config.General.requestName = 'RealData_noLFNDirectory_All_v0'
config.section_('JobType')
config.JobType.maxJobRuntimeMin = 2000
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'UnifiedScoutingVertexingTreeMaker.py'
config.section_('Data')
config.Data.inputDBS = 'global'
config.Data.totalUnits = 50000000
config.Data.allowNonValidInputDataset = True
config.Data.splitting = 'EventAwareLumiBased'
config.Data.inputDataset = '/ScoutingPFRun3/Run2024H-v1/HLTSCOUT'
config.Data.unitsPerJob = 50000
config.Data.outputDatasetTag = 'RealData_noLFNDirectory_All_v0'
config.Data.publication = False
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
