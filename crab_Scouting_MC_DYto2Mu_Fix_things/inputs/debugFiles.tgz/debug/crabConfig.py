from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.transferLogs = True
config.General.requestName = 'Scouting_MC_DYto2Mu_Fix_things'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.outputFiles = ['Scouting_MC_2024H_withHitCuts.root']
config.JobType.psetName = 'UnifiedScoutingVertexingPlotsMaker.py'
config.JobType.maxMemoryMB = 2500
config.section_('Data')
config.Data.outputDatasetTag = 'Scouting_MC_DYto2Mu_Fix_things'
config.Data.publication = False
config.Data.inputDataset = '/DYto2Mu-4Jets_Bin-MLL-50_TuneCP5_13p6TeV_madgraphMLM-pythia8/RunIII2024Summer24MiniAOD-140X_mcRun3_2024_realistic_v26-v3/MINIAODSIM'
config.Data.splitting = 'FileBased'
config.Data.unitsPerJob = 30
config.Data.allowNonValidInputDataset = True
config.Data.inputDBS = 'global'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
