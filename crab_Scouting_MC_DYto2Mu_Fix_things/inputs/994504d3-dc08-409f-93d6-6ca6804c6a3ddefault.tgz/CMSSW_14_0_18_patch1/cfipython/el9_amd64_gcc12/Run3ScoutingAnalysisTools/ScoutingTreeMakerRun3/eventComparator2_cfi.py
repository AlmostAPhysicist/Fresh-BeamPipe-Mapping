import FWCore.ParameterSet.Config as cms

eventComparator2 = cms.EDAnalyzer('EventComparator2Analyzer',
  displacedVerticesOffline = cms.InputTag('VertexerOffline'),
  displacedVerticesScouting = cms.InputTag('Vertexer'),
  tracksOffline = cms.InputTag('packedCandidateToTrack', 'Track'),
  tracksScouting = cms.InputTag('hltScoutingUnpackProducer', 'Track'),
  beamspot_src = cms.InputTag('offlineBeamSpot'),
  nEventsToSave = cms.int32(5),
  vertex_min_ntracks = cms.int32(2),
  vertex_max_chi2 = cms.double(-1),
  stopAfterSelectedVertices = cms.untracked.int32(10),
  mightGet = cms.optional.untracked.vstring
)
