import FWCore.ParameterSet.Config as cms

eventComparator = cms.EDAnalyzer('EventComparatorAnalyzer',
  displacedVerticesOffline = cms.InputTag('offlineDisplacedVertices'),
  displacedVerticesScouting = cms.InputTag('Vertexer'),
  tracksOffline = cms.InputTag('generalTracks'),
  tracksScouting = cms.InputTag('hltScoutingUnpackProducer', 'Track'),
  nEventsToSave = cms.int32(5),
  vertex_min_ntracks = cms.int32(2),
  vertex_max_chi2 = cms.double(-1),
  mightGet = cms.optional.untracked.vstring
)
