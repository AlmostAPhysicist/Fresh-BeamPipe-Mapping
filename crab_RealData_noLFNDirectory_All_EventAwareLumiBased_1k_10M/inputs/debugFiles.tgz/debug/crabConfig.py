from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'RealData_noLFNDirectory_All_EventAwareLumiBased_1k_10M'
config.General.transferLogs = True
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.psetName = 'UnifiedScoutingVertexingTreeMaker.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.outputDatasetTag = 'RealData_noLFNDirectory_All_EventAwareLumiBased_1k_10M'
config.Data.splitting = 'EventAwareLumiBased'
config.Data.allowNonValidInputDataset = True
config.Data.inputDataset = '/ScoutingPFRun3/Run2024H-v1/HLTSCOUT'
config.Data.publication = False
config.Data.unitsPerJob = 1000
config.Data.inputDBS = 'global'
config.Data.totalUnits = 10000000
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
