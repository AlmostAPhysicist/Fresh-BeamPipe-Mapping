from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.transferOutputs = True
config.General.requestName = 'ScoutingData_Updated_2mod15_v1'
config.section_('JobType')
config.JobType.maxMemoryMB = 3000
config.JobType.maxJobRuntimeMin = 2750
config.JobType.outputFiles = ['ScoutingTree_Output_PV.root']
config.JobType.psetName = 'UnifiedScoutingVertexingTreeMaker.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.unitsPerJob = 2
config.Data.publication = False
config.Data.outputDatasetTag = 'ScoutingData_Updated_2mod15_v1'
config.Data.splitting = 'FileBased'
config.Data.inputDBS = 'global'
config.Data.inputDataset = '/ScoutingPFRun3/Run2024H-v1/HLTSCOUT'
config.Data.allowNonValidInputDataset = True
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
