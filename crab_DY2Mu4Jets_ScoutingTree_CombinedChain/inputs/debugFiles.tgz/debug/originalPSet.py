import FWCore.ParameterSet.Config as cms
import os

process = cms.Process("CHAIN")

process.load("FWCore.MessageService.MessageLogger_cfi")
process.MessageLogger.cerr.FwkSummary.reportEvery = 100
process.MessageLogger.cerr.FwkReport.reportEvery = 100

process.options = cms.untracked.PSet(
    wantSummary = cms.untracked.bool(True),
    TryToContinue = cms.untracked.vstring('ProductNotFound')  # In case something missing in few events
)

process.maxEvents = cms.untracked.PSet(
    input = cms.untracked.int32(10)
)

# Input source
process.source = cms.Source("PoolSource",
    fileNames = cms.untracked.vstring(
        # crab will fill this
    )
)

# Global tag
process.load('Configuration.StandardSequences.FrontierConditions_GlobalTag_cff')
from Configuration.AlCa.GlobalTag import GlobalTag
process.GlobalTag = GlobalTag(process.GlobalTag, '133X_mcRun3_2024_realistic_v9', '')

# Geometry and Magnetic Field
process.load('Configuration.StandardSequences.GeometryRecoDB_cff')
process.load('Configuration.StandardSequences.MagneticField_cff')

# L1 Unpacking
process.load("EventFilter.L1TRawToDigi.gtStage2Digis_cfi")
process.gtStage2Digis.InputLabel = cms.InputTag("hltFEDSelectorL1")

# TFileService for final output
process.TFileService = cms.Service("TFileService",
    fileName = cms.string("DY2M_ScoutingTree_Output.root")  # This is the only output saved
)

# Step 1: HLT Scouting Unpacker
process.hltScoutingUnpackProducer = cms.EDProducer('HLTScoutingUnpackProducer',
    scoutingTrack = cms.InputTag('hltScoutingTrackPacker'),
    scoutingPrimaryVertex = cms.InputTag('hltScoutingPrimaryVertexPacker', 'primaryVtx'),
    producePFCHSCandidate = cms.bool(False),
    mightGet = cms.optional.untracked.vstring
)

# Step 2: Vertexer
process.load("RecoVertex.BeamSpotProducer.BeamSpot_cfi")
process.load("TrackingTools.TransientTrack.TransientTrackBuilder_cfi")

process.Vertexer = cms.EDProducer('Vertexer',
    seed_tracks_src = cms.InputTag('hltScoutingUnpackProducer', 'Track'),
    beamspot_src = cms.InputTag('offlineBeamSpot'),
    n_tracks_per_seed_vertex = cms.int32(2),
    max_seed_vertex_chi2 = cms.double(5),
    resolve_split_vertices_loose = cms.bool(False),
    resolve_split_vertices_tight = cms.bool(True),
    investigate_merged_vertices = cms.bool(False),
    use_2d_vertex_dist = cms.bool(False),
    use_2d_track_dist = cms.bool(False),
    merge_anyway_dist = cms.double(-1),
    merge_anyway_sig = cms.double(4),
    merge_shared_dist = cms.double(-1),
    merge_shared_sig = cms.double(4),
    max_track_vertex_dist = cms.double(-1),
    max_track_vertex_sig = cms.double(5),
    min_track_vertex_sig_to_remove = cms.double(1.5),
    remove_one_track_at_a_time = cms.bool(True),
    max_nm1_refit_dist3 = cms.double(-1),
    max_nm1_refit_distz = cms.double(0.005),
    max_nm1_refit_count = cms.int32(-1),
    verbose = cms.bool(False),
)

# Step 3: Scouting Tree Maker
L1Info = [
    "L1_HTT200er", "L1_HTT255er", "L1_HTT280er", "L1_HTT320er",
    "L1_HTT360er", "L1_HTT400er", "L1_HTT450er", "L1_ETT2000",
    "L1_SingleJet180", "L1_SingleJet200",
    "L1_DoubleJet30er2p5_Mass_Min250_dEta_Max1p5",
    "L1_DoubleJet30er2p5_Mass_Min300_dEta_Max1p5",
    "L1_DoubleJet30er2p5_Mass_Min330_dEta_Max1p5"
]

process.scoutingTree = cms.EDAnalyzer('ScoutingTreeMakerRun3',
    required_ntk = cms.int32(2),
    triggerresults = cms.InputTag("TriggerResults", "", "HLT"),
    ReadPrescalesFromFile = cms.bool(False),
    AlgInputTag = cms.InputTag("gtStage2Digis"),
    l1tAlgBlkInputTag = cms.InputTag("gtStage2Digis"),
    l1tExtBlkInputTag = cms.InputTag("gtStage2Digis"),
    doTrigger = cms.bool(True),
    doL1 = cms.bool(True),
    doPhiCorrection = cms.bool(False),
    luminosity = cms.double(108.96),   # fb-1
    crossSection = cms.double(1),       # fb
    l1Seeds = cms.vstring(L1Info),
    muons = cms.InputTag("hltScoutingMuonPacker"),
    electrons = cms.InputTag("hltScoutingEgammaPacker"),
    photons = cms.InputTag("hltScoutingEgammaPacker"),
    pfcands = cms.InputTag("hltScoutingPFPacker"),
    pfjets = cms.InputTag("hltScoutingPFPacker"),
    tracks = cms.InputTag("hltScoutingUnpackProducer", "Track"),
    primaryVertices = cms.InputTag("hltScoutingPrimaryVertexPacker", "primaryVtx"),
    displacedVertices = cms.InputTag("Vertexer"),
    pfMet = cms.InputTag("hltScoutingPFPacker", "pfMetPt"),
    pfMetPhi = cms.InputTag("hltScoutingPFPacker", "pfMetPhi"),
    rho = cms.InputTag("hltScoutingPFPacker", "rho"),
    beamspot_src = cms.InputTag('offlineBeamSpot'),
    genParticle_src = cms.InputTag('prunedGenParticles'),
    generatorName = cms.InputTag('generator')
)

# Full chain schedule
process.p = cms.Path(
    process.hltScoutingUnpackProducer +
    process.gtStage2Digis +
    process.offlineBeamSpot +
    process.Vertexer +
    process.scoutingTree
)
