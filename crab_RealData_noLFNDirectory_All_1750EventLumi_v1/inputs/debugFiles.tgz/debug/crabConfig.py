from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'RealData_noLFNDirectory_All_1750EventLumi_v1'
config.General.transferOutputs = True
config.General.transferLogs = True
config.section_('JobType')
config.JobType.psetName = 'UnifiedScoutingVertexingTreeMaker.py'
config.JobType.pluginName = 'Analysis'
config.JobType.maxJobRuntimeMin = 2000
config.section_('Data')
config.Data.inputDataset = '/ScoutingPFRun3/Run2024H-v1/HLTSCOUT'
config.Data.publication = False
config.Data.splitting = 'EventAwareLumiBased'
config.Data.allowNonValidInputDataset = True
config.Data.unitsPerJob = 1750
config.Data.inputDBS = 'global'
config.Data.outputDatasetTag = 'RealData_noLFNDirectory_All_1750EventLumi_v1'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
