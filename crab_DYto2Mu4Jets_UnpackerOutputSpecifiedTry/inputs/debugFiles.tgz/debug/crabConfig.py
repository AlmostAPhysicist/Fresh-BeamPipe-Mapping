from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.requestName = 'DYto2Mu4Jets_UnpackerOutputSpecifiedTry'
config.General.transferLogs = True
config.section_('JobType')
config.JobType.psetName = 'HLTScoutingUnpackProducer.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.unitsPerJob = 1
config.Data.totalUnits = 1
config.Data.outputPrimaryDataset = 'DYto2Mu4Jets_UnpackerOutputSpecifiedTry'
config.Data.splitting = 'FileBased'
config.Data.outputDatasetTag = 'DYto2Mu4Jets_UnpackerOutputSpecifiedTry'
config.Data.publication = True
config.Data.userInputFiles = ['root://cmsxrootd.fnal.gov//store/mc/RunIII2024Summer24MiniAOD/DYto2Mu-4Jets_Bin-MLL-50_TuneCP5_13p6TeV_madgraphMLM-pythia8/MINIAODSIM/140X_mcRun3_2024_realistic_v26-v2/2560000/ad749229-3094-410f-94e3-2e408518e395.root']
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
