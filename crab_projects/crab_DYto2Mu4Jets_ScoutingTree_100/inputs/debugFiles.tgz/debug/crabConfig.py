from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crab_projects'
config.General.requestName = 'DYto2Mu4Jets_ScoutingTree_100'
config.General.transferOutputs = True
config.General.transferLogs = True
config.section_('JobType')
config.JobType.psetName = 'tree.py'
config.JobType.pluginName = 'Analysis'
config.JobType.maxMemoryMB = 2500
config.section_('Data')
config.Data.unitsPerJob = 5
config.Data.inputDBS = 'phys03'
config.Data.outputDatasetTag = 'DYto2Mu4Jets_ScoutingTree_100'
config.Data.publication = True
config.Data.inputDataset = '/DYto2Mu-4Jets_Bin-MLL-50_TuneCP5_13p6TeV_madgraphMLM-pythia8/amalhotr-DYto2Mu4Jets_Vertexer_100_EventAwareLumiBased-8eb043b42a967140b9dd5cab43cfc767/USER'
config.Data.splitting = 'FileBased'
config.section_('Site')
config.Site.storageSite = 'T2_BR_SPRACE'
config.section_('User')
config.section_('Debug')
