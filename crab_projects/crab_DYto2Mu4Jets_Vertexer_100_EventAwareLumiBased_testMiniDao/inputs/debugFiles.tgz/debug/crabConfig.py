from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crab_projects'
config.General.requestName = 'DYto2Mu4Jets_Vertexer_100_EventAwareLumiBased_testMiniDao'
config.General.transferOutputs = True
config.General.transferLogs = True
config.section_('JobType')
config.JobType.psetName = 'Vertexer.py'
config.JobType.maxMemoryMB = 2500
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.totalUnits = 10
config.Data.inputDBS = 'global'
config.Data.splitting = 'EventAwareLumiBased'
config.Data.unitsPerJob = 5
config.Data.publication = True
config.Data.inputDataset = '/DYto2Mu-4Jets_Bin-MLL-50_TuneCP5_13p6TeV_madgraphMLM-pythia8/RunIII2024Summer24MiniAOD-140X_mcRun3_2024_realistic_v26-v2/MINIAODSIM'
config.Data.outputDatasetTag = 'DYto2Mu4Jets_Vertexer_100_EventAwareLumiBased_testMiniDao'
config.section_('Site')
config.Site.storageSite = 'T2_BR_SPRACE'
config.section_('User')
config.section_('Debug')
