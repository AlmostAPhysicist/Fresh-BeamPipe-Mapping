from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.workArea = 'crab_projects'
config.General.transferOutputs = True
config.General.requestName = 'DYto2Mu4Jets_Vertexer_100_Automatic'
config.section_('JobType')
config.JobType.maxMemoryMB = 2500
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'Vertexer.py'
config.section_('Data')
config.Data.outputDatasetTag = 'DYto2Mu4Jets_Vertexer_100_Automatic'
config.Data.splitting = 'Automatic'
config.Data.inputDataset = '/DYto2Mu-4Jets_Bin-MLL-50_TuneCP5_13p6TeV_madgraphMLM-pythia8/amalhotr-DYto2Mu4Jets_Unpacker_100-49feb6938084587a06052f9676570a55/USER'
config.Data.inputDBS = 'phys03'
config.Data.publication = True
config.section_('Site')
config.Site.storageSite = 'T2_BR_SPRACE'
config.section_('User')
config.section_('Debug')
