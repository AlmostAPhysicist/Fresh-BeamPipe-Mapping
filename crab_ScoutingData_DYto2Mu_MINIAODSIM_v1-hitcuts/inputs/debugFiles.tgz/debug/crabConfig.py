from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.transferOutputs = True
config.General.requestName = 'ScoutingData_DYto2Mu_MINIAODSIM_v1-hitcuts'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.outputFiles = ['Scouting_MC_DYto2Mu_withHitCuts.root']
config.JobType.psetName = 'UnifiedScoutingVertexingPlotsMaker.py'
config.JobType.maxMemoryMB = 2500
config.section_('Data')
config.Data.inputDBS = 'global'
config.Data.outputDatasetTag = 'ScoutingData_DYto2Mu_MINIAODSIM_v1-hitcuts'
config.Data.publication = False
config.Data.splitting = 'FileBased'
config.Data.inputDataset = '/DYto2Mu-4Jets_Bin-MLL-50_TuneCP5_13p6TeV_madgraphMLM-pythia8/RunIII2024Summer24MiniAOD-140X_mcRun3_2024_realistic_v26-v3/MINIAODSIM'
config.Data.unitsPerJob = 5
config.Data.allowNonValidInputDataset = True
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
